import tkinter as tk
import pygsheets
from threading import Thread
# from model_training import train_model # Replace model_training with the .py file name and train_model with the function

def save_data_to_google_sheets(data):
    gc = pygsheets.authorize(service_file='credentials.json')
    sheet = gc.open('Golf Swing Analysis Test Sheet')
    worksheet = sheet.sheet1
    worksheet.append_table(values=[list(data.values())], end='A1', dimension='ROWS', overwrite=False)

'''def end_session(self):
    user_data = self.get_user_data()
    save_data_to_google_sheets(user_data)
    print("Session ended. User data saved to Google Sheets:", user_data)
    self.master.quit()'''


class App:
    def __init__(self, master):
        self.master = master
        master.title("PythonGuides")
        master.geometry("500x300")

        self.first_name = tk.Entry(master)
        self.last_name = tk.Entry(master)
        self.email = tk.Entry(master)
        self.phone = tk.Entry(master)
        self.city = tk.Entry(master)
        self.state = tk.Entry(master)

        tk.Label(master, text="First Name").pack()
        self.first_name.pack()
        tk.Label(master, text="Last Name").pack()
        self.last_name.pack()
        tk.Label(master, text="Email").pack()
        self.email.pack()
        tk.Label(master, text="Phone").pack()
        self.phone.pack()
        tk.Label(master, text="City").pack()
        self.city.pack()
        tk.Label(master, text="State").pack()
        self.state.pack()

        self.start_button = tk.Button(master, text="Start Session", command=self.start_session, state=tk.DISABLED)
        self.start_button.pack()

        self.end_button = tk.Button(master, text="End Session", command=self.end_session, state=tk.DISABLED)
        self.end_button.pack()

        self.update_start_button_state()

        self.first_name.bind("<KeyRelease>", self.update_start_button_state)
        self.last_name.bind("<KeyRelease>", self.update_start_button_state)
        self.email.bind("<KeyRelease>", self.update_start_button_state)
        self.phone.bind("<KeyRelease>", self.update_start_button_state)
        self.city.bind("<KeyRelease>", self.update_start_button_state)
        self.state.bind("<KeyRelease>", self.update_start_button_state)

    '''def update_start_button_state(self, event=None):
        if all(self.get_user_data().values()):
            self.start_button["state"] = tk.NORMAL
        else:
            self.start_button["state"] = tk.DISABLED'''
    
    def update_start_button_state(self, event=None):
        user_data_values = list(self.get_user_data().values())
        # print(f"User data values: {user_data_values}")
        if all(user_data_values):
            # print("Enabling Start Session button")
            self.start_button["state"] = tk.NORMAL
        else:
            # print("Disabling Start Session button")
            self.start_button["state"] = tk.DISABLED

    def get_user_data(self):
        return {
            "first_name": self.first_name.get(),
            "last_name": self.last_name.get(),
            "email": self.email.get(),
            "phone": self.phone.get(),
            "city": self.city.get(),
            "state": self.state.get()
        }

    def start_session(self):
        self.start_button["state"] = tk.DISABLED
        self.thread = Thread(target=self.run_tensorflow_script)
        self.thread.start()

    def run_tensorflow_script(self):
        #history = train_model()  # Call your script here
        #print(history.history)
        print('hello')
        self.end_button["state"] = tk.NORMAL

    def end_session(self):
        user_data = self.get_user_data()
        
        # Save user_data to Google Sheets
        try:
            save_data_to_google_sheets(user_data)
            print("Session ended. User data saved to Google Sheets:", user_data)
        except Exception as e:
            print(f"Error saving data to Google Sheets: {e}")
        
        """Clear all the input fields."""
        self.first_name.delete(0, 'end')
        self.last_name.delete(0, 'end')
        self.email.delete(0, 'end')
        self.phone.delete(0, 'end')
        self.city.delete(0, 'end')
        self.state.delete(0, 'end')

root = tk.Tk()
app = App(root)
root.mainloop()
